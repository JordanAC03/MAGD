var x = []
function setup() {
  createCanvas(400, 400);
  noStroke();
  fill(255,200);
  for (var i = 0; i < 1000; i++){
    x[i] = random(-1000, 200);
  }
}

function draw() {
  background(220);
  for (var i = 0; i < x.length; i++){
    x[i] += 0.8;
    var y = i * 0.9;
    triangle(x[i], y, 5, 28, 0.28, 0.50);
  }
}