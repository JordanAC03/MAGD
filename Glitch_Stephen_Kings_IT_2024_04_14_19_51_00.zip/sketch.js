let glitch;
let ITPath = 'IT.jpg';
function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);
	imageMode(CENTER);
	glitch = new Glitch();
	glitch.pixelate(.16);
	glitch.loadBytes(ITPath, function() {
		glitch.randomBytes(25);
	});
	glitch.loadType('jpg');
	glitch.loadQuality(1.92)
	glitch.loadImage(ITPath);
	loadImage(ITPath, function(img) {
		glitch.loadImage(img);
	});
	glitch.debug(false);
}
function draw() {
	glitch.resetBytes();
	glitch.randomBytes(1)
	glitch.randomBytes(2, 50)
	glitch.replaceHex('ffdb00430101', 'ffdb00430155');
	glitch.buildImage();
	image(glitch.image, width / 2, height / 2)
}

