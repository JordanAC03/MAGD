
var a = 100

function setup() {
  createCanvas(400, 400);
  fill (a, a, 255)
  ellipseMode(RADIUS);
  colorMode(RGB,100,500,10,255);
}

function draw() {
  background(255,a,0);
  rect(200,200, 14, 14);
  ellipse( 100, 100, 12, 12);
  
  var d = dist(mouseX, mouseY, 100, 100);
  if (d < 12 && mouseIsPressed){
    a = 300; 
  }
  else{
    a = 100;
  }
  ellipse(300,100, 10, 10);
  if (keyIsPressed){
    if (key == 'b'){
      if (d>10){
        fill(150);
      }
    }
  }
  
}
function mousePressed() {

	if ((mouseX > 200) && (mouseX < 200+14) && (mouseY > 200) && (mouseY < 200+14)) {
		
		a = 500;

	}
}
